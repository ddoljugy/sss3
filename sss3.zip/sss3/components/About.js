
import React from 'react';

function About() {
  return (
    <div>
      <p>Advice and assistance<br/>
      From information on car brands and models, to knowledge on financing and affordability -<br/>
      Blue Auto is here to help you!<br/>
      <span style={{ color: 'grey', cursor: 'not-allowed' }}>Contact us today.</span>
      </p>
    </div>
  );
}

export default About;
