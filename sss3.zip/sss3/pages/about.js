import React from "react";
import About from "../components/About";

const AboutUs = () => {
  return <About />;
};

export default About;
