const mysql = require("mysql2/promise");

const connection = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

async function dbConnect() {
  try {
    await connection.getConnection();
    console.log("MySQL connection established");
  } catch (error) {
    console.error("Database connection error:", error);
  }
}

module.exports = { dbConnect, connection };
